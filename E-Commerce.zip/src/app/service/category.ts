export interface Category {
    name:string,
    image:string
}
