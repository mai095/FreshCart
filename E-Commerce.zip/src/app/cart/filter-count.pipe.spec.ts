import { FilterCountPipe } from './filter-count.pipe';

describe('FilterCountPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCountPipe();
    expect(pipe).toBeTruthy();
  });
});
