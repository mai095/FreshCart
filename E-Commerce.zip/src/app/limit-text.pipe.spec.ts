import { LimitTextPipe } from './limit-text.pipe';

describe('LimitTextPipe', () => {
  it('create an instance', () => {
    const pipe = new LimitTextPipe();
    expect(pipe).toBeTruthy();
  });
});
