export interface BrandDetails {
    name:string,
    image:string,
    slug:string
}
